def main():
    print("This is a guessing game")
    given = int(input("Enter your number: "))
    answer = 6
    if given > answer:
        print("Your guess is incorrect the number", given, "is too large.")
    elif given < answer:
        print("Your guess is incorrect the number", given,"is too small")
    else:
        print("You guessed right.")

main()